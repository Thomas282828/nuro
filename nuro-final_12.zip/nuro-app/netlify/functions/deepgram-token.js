// Génère un token temporaire Deepgram pour le client
// La clé API ne quitte jamais le serveur
exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  const DEEPGRAM_API_KEY = process.env.DEEPGRAM_API_KEY;
  if (!DEEPGRAM_API_KEY) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Clé Deepgram manquante' }),
    };
  }

  try {
    // Crée un token temporaire valide 30 secondes
    const response = await fetch('https://api.deepgram.com/v1/auth/grant', {
      method: 'POST',
      headers: {
        'Authorization': `Token ${DEEPGRAM_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        time_to_live_in_seconds: 30,
        scopes: ['usage:write'],
      }),
    });

    if (!response.ok) {
      // Fallback : retourner la clé directement si les tokens temporaires ne sont pas disponibles
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ key: DEEPGRAM_API_KEY }),
      };
    }

    const data = await response.json();
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ key: data.key }),
    };
  } catch (err) {
    // Fallback sécurisé
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ key: DEEPGRAM_API_KEY }),
    };
  }
};

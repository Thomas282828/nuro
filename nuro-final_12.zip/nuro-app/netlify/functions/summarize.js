exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Méthode non autorisée' }) };
  }

  const CLAUDE_API_KEY = process.env.CLAUDE_API_KEY;
  if (!CLAUDE_API_KEY) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: 'Clé Claude manquante' }) };
  }

  let transcript;
  try {
    const body = JSON.parse(event.body);
    transcript = body.transcript;
  } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Corps de requête invalide' }) };
  }

  if (!transcript || transcript.trim().length < 10) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Transcription trop courte' }) };
  }

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': CLAUDE_API_KEY,
        'anthropic-version': '2023-06-01',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 1024,
        system: `Tu es un assistant qui analyse des transcriptions audio et produit des résumés clairs et utiles en français.
        
Réponds UNIQUEMENT en JSON valide avec cette structure exacte :
{
  "titre": "Titre court et descriptif (max 8 mots)",
  "resume": "Résumé en 2-3 phrases claires",
  "points_cles": ["point 1", "point 2", "point 3"],
  "actions": ["action 1", "action 2"]
}

Si aucune action n'est mentionnée, retourne un tableau vide pour "actions".
Ne mets aucun texte avant ou après le JSON.`,
        messages: [
          {
            role: 'user',
            content: `Analyse cette transcription et génère un résumé structuré :\n\n${transcript}`,
          },
        ],
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      console.error('Erreur Claude:', err);
      return { statusCode: 502, headers, body: JSON.stringify({ error: 'Erreur API Claude' }) };
    }

    const data = await response.json();
    const rawText = data.content?.[0]?.text || '{}';

    let summary;
    try {
      summary = JSON.parse(rawText.replace(/```json|```/g, '').trim());
    } catch {
      summary = {
        titre: 'Résumé',
        resume: rawText,
        points_cles: [],
        actions: [],
      };
    }

    return { statusCode: 200, headers, body: JSON.stringify(summary) };
  } catch (err) {
    console.error('Erreur serveur:', err);
    return { statusCode: 500, headers, body: JSON.stringify({ error: 'Erreur serveur' }) };
  }
};

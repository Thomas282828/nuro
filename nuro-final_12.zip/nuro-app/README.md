# Nuro — App de transcription vocale

## Déploiement sur Netlify (10 minutes)

### 1. Préparer les fichiers
Télécharge ce dossier entier, puis crée un compte sur [netlify.com](https://netlify.com) si ce n'est pas encore fait.

### 2. Déployer sur Netlify
- Va sur app.netlify.com
- Clique sur "Add new site" → "Deploy manually"
- Glisse-dépose le dossier entier dans la zone prévue
- Netlify te donne une URL publique en quelques secondes (ex: `nuro-xyz.netlify.app`)

### 3. Ajouter les variables d'environnement (OBLIGATOIRE)
Sans ces clés, l'app ne peut pas transcrire ni résumer.

- Dans ton site Netlify → **Site configuration** → **Environment variables**
- Ajoute ces deux variables :

| Nom | Valeur |
|-----|--------|
| `DEEPGRAM_API_KEY` | Ta clé Deepgram (console.deepgram.com) |
| `CLAUDE_API_KEY` | Ta clé Anthropic (console.anthropic.com) |

- Clique sur **Save**, puis **Deploys** → **Trigger deploy** → **Deploy site**

### 4. Tester
Ouvre ton URL Netlify dans Chrome ou Safari, crée un compte, et enregistre !

### Sur mobile (iOS/Android)
- Ouvre l'URL dans Safari (iOS) ou Chrome (Android)
- iOS : partage → "Sur l'écran d'accueil"
- Android : menu → "Ajouter à l'écran d'accueil"
- Nuro s'installe comme une vraie app !

## Structure du projet

```
nuro-app/
├── index.html              # App complète (auth + dashboard + detail)
├── manifest.json           # Config PWA pour installation mobile
├── netlify.toml            # Config Netlify
└── netlify/functions/
    ├── deepgram-token.js   # Proxy sécurisé Deepgram (masque la clé API)
    └── summarize.js        # Génération de résumé via Claude Haiku
```

## Coûts estimés

- **Netlify** : Gratuit (125k appels de fonctions/mois inclus)
- **Deepgram** : 200$ de crédits offerts (~430h de transcription)
- **Claude Haiku** : 5$ de crédits offerts (~1000 résumés)
